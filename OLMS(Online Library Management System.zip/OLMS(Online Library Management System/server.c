#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>

#define PORT 8080
#define BUF_SIZE 1024

pthread_mutex_t file_lock;

// Function to authenticate users using credentials stored in files
int authenticate(const char* user_type, const char* username, const char* password) {
    FILE *file;
    char file_username[BUF_SIZE], file_password[BUF_SIZE];
    char *filename;

    if (strcmp(user_type, "admin") == 0) {
        filename = "admin_credentials.txt";
    } else {
        filename = "user_credentials.txt";
    }

    file = fopen(filename, "r");
    if (file != NULL) {
        while (fscanf(file, "%s %s", file_username, file_password) != EOF) {
            if (strcmp(username, file_username) == 0 && strcmp(password, file_password) == 0) {
                fclose(file);
                if (strcmp(user_type, "admin") == 0) 
                    return 1;
                else
                    return 2;
            }
        }
        fclose(file);
    }

    return 0; // Authentication failed
}

int username_exists(const char *filename, const char *username) {
    FILE *file;
    char line[BUF_SIZE];
    char existing_username[BUF_SIZE];

    file = fopen(filename, "r");
    if (file != NULL) {
        while (fgets(line, sizeof(line), file) != NULL) {
            sscanf(line, "%s", existing_username);
            if (strcmp(existing_username, username) == 0) {
                fclose(file);
                return 1; // Username exists
            }
        }
        fclose(file);
    }
    return 0; // Username does not exist
}

// Function to add a new user
int add_user(const char* user_type, const char* new_username, const char* new_password) {
    FILE *file;
    char *filename;

    if (strcmp(user_type, "admin") == 0) {
        filename = "admin_credentials.txt";
    } else {
        filename = "user_credentials.txt";
    }

    if (username_exists(filename, new_username)) {
        // printf("Username already exists. Cannot add user.\n");
        return 0;
    }

    file = fopen(filename, "a");
    if (file != NULL) {
        fprintf(file, "%s %s\n", new_username, new_password);
        fclose(file);
    }
    return 1;
}

// Function to delete a user
int delete_user(const char* user_type, const char* username) {
    FILE *file, *temp_file;
    char file_username[BUF_SIZE], file_password[BUF_SIZE];
    char *filename;
    int c1 = 0;
    if (strcmp(user_type, "admin") == 0) {
        filename = "admin_credentials.txt";
    } else {
        filename = "user_credentials.txt";
    }

    file = fopen(filename, "r");
    temp_file = fopen("temp.txt", "w");
    if (file != NULL && temp_file != NULL) {
        while (fscanf(file, "%s %s", file_username, file_password) != EOF) {
            if (strcmp(file_username, username) != 0) {
                fprintf(temp_file, "%s %s\n", file_username, file_password);
            }
            else{
                c1 = 1;
            }
        }
        // removing database file of the user
        if(c1 && strcmp(user_type,"user") == 0)
        {
            char user_db_filename[BUF_SIZE];
            snprintf(user_db_filename, sizeof(user_db_filename), "database/%s.txt", username);
            remove(user_db_filename);
        }

        fclose(file);
        fclose(temp_file);
        remove(filename);
        rename("temp.txt", filename);
    }
    if(c1 == 0)
        return 0;
    else
        return 1;
}

// Function to add a new book
void add_book(const char* book_info) {
    int fd = open("library_db.txt", O_RDWR | O_CREAT | O_APPEND, 0644);
    if (fd >= 0) {
        write(fd, book_info, strlen(book_info));
        write(fd, "\n", 1);
        close(fd);
    }
}

int delete_book(const char* book_name) {
    FILE *file, *temp_file;
    char line[BUF_SIZE];
    int c = 0;
    file = fopen("library_db.txt", "r");
    temp_file = fopen("temp_db.txt", "w");
    if (file != NULL && temp_file != NULL) {
        while (fgets(line, sizeof(line), file) != NULL) {
            // Trim trailing newline characters
            line[strcspn(line, "\n")] = '\0';
            //printf("%s\n",line);
            char dup_line[BUF_SIZE];
            strcpy(dup_line,line);
            // Extract book name from the line
            char *token = strtok(line, ",");

            //printf("%s \n",token);
            if (token != NULL) {
                // Compare extracted book name with provided book_name
                if (strcmp(token, book_name) != 0) {
                    // Book name does not match, so write the line to temp file
                    // fputs(line, temp_file);

                    fprintf(temp_file,"%s\n",dup_line);
                    //printf("%s\n",line);
                    //fputc('\n', temp_file);
                } 
                else{
                    c = 1;
                }
            } 
        }
        fclose(file);
        fclose(temp_file);
        remove("library_db.txt");
        rename("temp_db.txt", "library_db.txt");
    }
    if(c == 0)
        return 0;
    else
        return 1;
}

int modify_book(const char* book_name,const char* quantity)
{
    FILE *file, *temp_file;
    char line[BUF_SIZE];
    int c = 0;

    file = fopen("library_db.txt", "r");
    temp_file = fopen("temp_db.txt", "w");

    if (file != NULL && temp_file != NULL) {
        while (fgets(line, sizeof(line), file) != NULL) {
            //line[strcspn(line, "\n")] = '\0';

            char line_copy[BUF_SIZE];
            strcpy(line_copy, line);

            char *token = strtok(line_copy, ",");
            char *author = strtok(NULL, ",");
            char *quantity_str = strtok(NULL, ",");


            if (token != NULL && author != NULL && quantity_str != NULL) 
            {
                char *book_name_from_file = strtok(token, "\n");
                if (strcmp(book_name_from_file, book_name) == 0) 
                {
                    int quantity_req = atoi(quantity);
                    fprintf(temp_file, "%s,%s,%d\n", book_name_from_file, author, quantity_req);
                    c=1;
                } 
                else 
                {
                    fputs(line, temp_file);
                    }
            } 
            else 
            {
                fputs(line, temp_file);
            }
        }

        fclose(file);
        fclose(temp_file);
        remove("library_db.txt");
        rename("temp_db.txt", "library_db.txt");
    }
     if(c == 0)
        return 0;
    else
        return 1;

}

int borrow_books(const char* username,const char* book_name)
{
    FILE *file, *temp_file, *user_file;
    char line[BUF_SIZE];
    char user_db_filename[BUF_SIZE];
    int c = 0;
    snprintf(user_db_filename, sizeof(user_db_filename), "database/%s.txt", username);

     file = fopen("library_db.txt", "r");
    temp_file = fopen("temp_db.txt", "w");
    user_file = fopen(user_db_filename, "a");
    if (file != NULL && temp_file != NULL && user_file != NULL) {
        while (fgets(line, sizeof(line), file) != NULL) {
            //line[strcspn(line, "\n")] = '\0';

            char line_copy[BUF_SIZE];
            strcpy(line_copy, line);
            
            char *token = strtok(line_copy, ",");
            char *author = strtok(NULL, ",");
            char *quantity_str = strtok(NULL, ",");
            
            if (token != NULL && author != NULL && quantity_str != NULL) {
                char *book_name_from_file = strtok(token, "\n");
                if (strcmp(book_name_from_file, book_name) == 0) {
                    int quantity = atoi(quantity_str);
                    if (quantity > 0) {
                        quantity--;
                        fprintf(temp_file, "%s,%s,%d\n", book_name_from_file, author, quantity);
                        fprintf(user_file, "%s,%s\n", book_name_from_file, author);
                        c = 1;
                    } else {
                        fputs(line, temp_file);
                    }
                } else {
                    fputs(line, temp_file);
                }
            } else {
                fputs(line, temp_file);
            }
        }
        fclose(file);
        fclose(temp_file);
        fclose(user_file);
        remove("library_db.txt");
        rename("temp_db.txt", "library_db.txt");
    }
    if(c == 0)
        return 0;
    else
        return 1;

}

int return_books(const char* username, const char* book_name) {
    FILE *file, *temp_file, *user_file;
    char line[BUF_SIZE];
    char user_db_filename[BUF_SIZE];
    int c = 0;
    snprintf(user_db_filename, sizeof(user_db_filename), "database/%s.txt", username);

    file = fopen("library_db.txt", "r");
    // printf("file 1\n");
    //  if (file == NULL) {
    //     perror("Failed to open library_db.txt");
    // } else {
    //     printf("Successfully opened library_db.txt\n");
    // }

    temp_file = fopen("temp_db.txt", "w");
    // printf("file 2\n");
    // if (temp_file == NULL) {
    //     perror("Failed to open temp_db.txt");
    // } else {
    //     printf("Successfully opened temp_db.txt\n");
    // }
    // printf("%s\n",user_db_filename);
    user_file = fopen(user_db_filename, "r");
    // printf("file 3\n");

    // if (user_file == NULL) {
    //     perror("Failed to open user database file");
    // } else {
    //     printf("Successfully opened %s\n", user_db_filename);
    // }

    int flag = 0;
        // Remove book from user's database
        FILE *temp_user_file = fopen("temp_user_db.txt", "w");
        if (temp_user_file != NULL) {
            while (fgets(line, sizeof(line), user_file) != NULL) {
                char temp_lline[BUF_SIZE];
                strcpy(temp_lline,line);
                char *token = strtok(line, ",");
                if (token != NULL && strcmp(token, book_name) != 0) {
                    fputs(temp_lline, temp_user_file);
                }
                else 
                    flag++;
                if(flag > 1)
                    fputs(temp_lline, temp_user_file);

            }
            fclose(temp_user_file);
            remove(user_db_filename);
            rename("temp_user_db.txt", user_db_filename);
        }

        printf("%d\n",flag);
    if (file != NULL && temp_file != NULL && user_file != NULL && flag !=0) {
        //printf("iffff \n");
        
        while (fgets(line, sizeof(line), file) != NULL) {
           //printf("whileee \n");
           //line[strcspn(line, "\n")] = '\0';
            //printf("%s\n",line);
            char line_copy[BUF_SIZE];
            strcpy(line_copy, line);

            char *token = strtok(line_copy, ",");
            char *author = strtok(NULL, ",");
            char *quantity_str = strtok(NULL, ",");
            // printf("asjfhdja\n");
            // printf("token : %s\n",token);
            // printf("book name : %s\n",book_name);
            if (token != NULL && author != NULL && quantity_str != NULL) {
                //char *book_name_from_file = strtok(token, "\n");
                if (strcmp(token, book_name) == 0) {
                    int quantity = atoi(quantity_str);
                    quantity++;
                    fprintf(temp_file, "%s,%s,%d\n", token, author, quantity);
                    c = 1;
                } else {
                    fputs(line, temp_file);
                }
            } else {
                fputs(line, temp_file);
            }
        }

        fclose(file);
        fclose(temp_file);
        fclose(user_file);
        remove("library_db.txt");
        rename("temp_db.txt", "library_db.txt");
    }
    if(c == 0)
        return 0;
    else 
        return 1;
}

void* handle_client(void* client_socket) {
    int new_socket = *(int*)client_socket;
    free(client_socket);
    char buffer[BUF_SIZE];
    char user_type[BUF_SIZE], username[BUF_SIZE], password[BUF_SIZE];
    char login_type[BUF_SIZE];
    int n;

    // Notify server that a client connection has been established
    printf("Client connected on socket %d\n", new_socket);
    // Notify client that the connection is established
    send(new_socket, "Connection established\n", 23, 0);

    // LOGIN or SIGNUP
    //printf("lt\n");
    n = read(new_socket,login_type,BUF_SIZE);
    login_type[n] = '\0';
    //printf("lt\n");
    // Receive user type
    //printf("ut\n");
    // n = read(new_socket, user_type, BUF_SIZE);
    // user_type[n] = '\0';
    // //printf("ut\n");
    
    // // Receive username and password
    // //printf("user\n");
    // n = read(new_socket, username, BUF_SIZE);
    // username[n] = '\0';
    // //printf("user\n");

    // //printf("pass\n");
    // n = read(new_socket, password, BUF_SIZE);
    // password[n] = '\0';
    // //printf("pass\n");

        if(strcmp(login_type,"SIGN_UP") == 0)
        {
            // char new_username[BUF_SIZE], new_password[BUF_SIZE];
            // n = read(new_socket, new_username, BUF_SIZE);
            // new_username[n] = '\0';
            // n = read(new_socket, new_password, BUF_SIZE);
            // new_password[n] = '\0';
            n = read(new_socket, user_type, BUF_SIZE);
            user_type[n] = '\0';
            //printf("ut\n");
            
            // Receive username and password
            //printf("user\n");
            n = read(new_socket, username, BUF_SIZE);
            username[n] = '\0';
            //printf("user\n");

            //printf("pass\n");
            n = read(new_socket, password, BUF_SIZE);
            password[n] = '\0';
            //printf("pass\n");
            pthread_mutex_lock(&file_lock);
            int sign_up_status = add_user("user",username,password);
            pthread_mutex_unlock(&file_lock);
            if (sign_up_status == 0) {
                send(new_socket, "Username already exists. Sign up failed.\n", 41, 0);
            } else {
                send(new_socket, "Sign up successful. You can now log in.\n", 40, 0);
            }
        }
    
    // LOGIN or SIGNUP
    // n = read(new_socket,login_type,BUF_SIZE);
    // login_type[n] = '\0';
    // printf("%s\n",login_type);
    // Receive user type
    n = read(new_socket, user_type, BUF_SIZE);
    user_type[n] = '\0';
    //printf("%s\n",user_type);
    // Receive username and password
    n = read(new_socket, username, BUF_SIZE);
    username[n] = '\0';
    //printf("%s\n",username);
    n = read(new_socket, password, BUF_SIZE);
    password[n] = '\0';
   // printf("%s\n",password);
    // Authenticate user
    int user_type_code = authenticate(user_type, username, password);
    //printf("%d\n",user_type_code);
    if (user_type_code == 0) {
        send(new_socket, "Authentication failed\n", 22, 0);
        close(new_socket);
        return NULL;
    } else if (user_type_code == 1) {
        send(new_socket, "Admin authenticated\n", 20, 0);
    } else if (user_type_code == 2) {
        send(new_socket, "User authenticated\n", 19, 0);
    }

    while ((n = read(new_socket, buffer, BUF_SIZE)) > 0) {
        buffer[n] = '\0';
        printf("Received: %s\n", buffer);

        if (strcmp(buffer, "ADD_BOOK") == 0 && user_type_code == 1) {
            char book_info[BUF_SIZE];
            n = read(new_socket, book_info, BUF_SIZE);
            book_info[n] = '\0';
            pthread_mutex_lock(&file_lock);
            add_book(book_info);
            pthread_mutex_unlock(&file_lock);
            send(new_socket, "Book added successfully\n", 24, 0);
        } else if (strcmp(buffer, "DELETE_BOOK") == 0 && user_type_code == 1) {
            char book_name[BUF_SIZE];
            n = read(new_socket, book_name, BUF_SIZE);
            book_name[n] = '\0';
            pthread_mutex_lock(&file_lock);
            int ans = delete_book(book_name);
            pthread_mutex_unlock(&file_lock);
            if(ans == 0)
                {
                    send(new_socket, "Select Valid Book\n", 18, 0);
                    }
            else{
            send(new_socket, "Book deleted successfully\n", 26, 0);}
        }
        else if(strcmp(buffer, "MODIFY_BOOK") ==0 && user_type_code == 1)
        {
            char book_name[BUF_SIZE];
            char quantity[BUF_SIZE];
            n = read(new_socket, book_name, BUF_SIZE);
            book_name[n] = '\0';
            n = read(new_socket, quantity, BUF_SIZE);
            quantity[n] = '\0';
            pthread_mutex_lock(&file_lock);
            int ans = modify_book(book_name,quantity);
            pthread_mutex_unlock(&file_lock);
            if(ans == 0)
                {
                    send(new_socket, "Select Valid Book\n", 18, 0);
                    }
            else{
            send(new_socket, "Book modified successfully\n", 26, 0);}

        }
        
         else if (strcmp(buffer, "ADD_USER") == 0 && user_type_code == 1) {
            char new_username[BUF_SIZE], new_password[BUF_SIZE];
            n = read(new_socket, new_username, BUF_SIZE);
            new_username[n] = '\0';
            n = read(new_socket, new_password, BUF_SIZE);
            new_password[n] = '\0';
            pthread_mutex_lock(&file_lock);
            int ans2 = add_user("user", new_username, new_password);
            pthread_mutex_unlock(&file_lock);
            if(ans2 == 0)
                send(new_socket, "User already exist\n", 19, 0);
            else
                send(new_socket, "User added successfully\n", 24, 0);
        } else if (strcmp(buffer, "DELETE_USER") == 0 && user_type_code == 1) {
            char del_username[BUF_SIZE];
            n = read(new_socket, del_username, BUF_SIZE);
            del_username[n] = '\0';
            pthread_mutex_lock(&file_lock);
            int ans1 = delete_user("user", del_username);
            pthread_mutex_unlock(&file_lock);
            if (ans1 == 0)
                send(new_socket, "Select Valid User\n", 18, 0);
            else
                send(new_socket, "User deleted successfully\n", 26, 0);
        } 
        else if (strcmp(buffer, "ADD_ADMIN") == 0 && user_type_code == 1) {
            char new_username[BUF_SIZE], new_password[BUF_SIZE];
            n = read(new_socket, new_username, BUF_SIZE);
            new_username[n] = '\0';
            n = read(new_socket, new_password, BUF_SIZE);
            new_password[n] = '\0';
            pthread_mutex_lock(&file_lock);
            int ans3 = add_user("admin", new_username, new_password);
            pthread_mutex_unlock(&file_lock);
            if(ans3 == 0)
                send(new_socket, "Admin already exist\n", 20, 0);
            else
                send(new_socket, "Admin added successfully\n", 25, 0);
        } 
        else if (strcmp(buffer, "DELETE_ADMIN") == 0 && user_type_code == 1) {
            char del_username[BUF_SIZE];
            n = read(new_socket, del_username, BUF_SIZE);
            del_username[n] = '\0';
            pthread_mutex_lock(&file_lock);
            int ans1 = delete_user("admin", del_username);
            pthread_mutex_unlock(&file_lock);
            if (ans1 == 0)
                send(new_socket, "Select Valid Admin\n", 19, 0);
            else
                send(new_socket, "ADMIN deleted successfully\n", 27, 0);
        } 
        else if (strcmp(buffer, "VIEW_LIBRARY") == 0) {
            pthread_mutex_lock(&file_lock);
            int fd = open("library_db.txt", O_RDONLY);
            if (fd >= 0) {
                struct stat file_stat;
                if (fstat(fd, &file_stat) == 0 && file_stat.st_size == 0) {
                    send(new_socket, "File is empty\n", 14, 0);
                }
                else{
                while ((n = read(fd, buffer, BUF_SIZE)) > 0) {
                    write(new_socket, buffer, n);
                }
                }
                close(fd);
            } else {
                send(new_socket, "Failed to open library database\n", 31, 0);
            }
            pthread_mutex_unlock(&file_lock);
        } 
        else if(strcmp(buffer, "BORROW_BOOK") == 0 && user_type_code == 2)
        {
            char new_username[BUF_SIZE], new_book[BUF_SIZE];
            //n = read(new_socket, new_username, BUF_SIZE);
            //new_username[n] = '\0';
            n = read(new_socket, new_book, BUF_SIZE);
            new_book[n] = '\0';
            pthread_mutex_lock(&file_lock);
            //borrow_books(new_username,new_book);
            int ans_borrow = borrow_books(username,new_book);
            pthread_mutex_unlock(&file_lock);
            if(ans_borrow == 0)
                send(new_socket, "Book not available\n", 19, 0);
            else
                send(new_socket, "Book borrowed successfully\n", 27, 0);
        }

        else if (strcmp(buffer, "RETURN_BOOK") == 0 && user_type_code == 2) {
            char new_username[BUF_SIZE], book_name[BUF_SIZE];
            //n = read(new_socket, username, BUF_SIZE);
            //username[n] = '\0';
            n = read(new_socket, book_name, BUF_SIZE);
            book_name[n] = '\0';

            pthread_mutex_lock(&file_lock);
            int ans_return = return_books(username,book_name);
            pthread_mutex_unlock(&file_lock);
            if(ans_return == 0)
                send(new_socket, "Book returned un-successfully\n", 30, 0);
            else
                send(new_socket, "Book returned successfully\n", 27, 0);
        }

        else if (strcmp(buffer,"VIEW_BOOK") == 0 && user_type_code == 2)
        {
            // char file_name[BUF_SIZE];
            // n = read(new_socket,file_name,BUF_SIZE)
            // file_name[n] = '\0';
            printf("view book please \n");
            pthread_mutex_lock(&file_lock);
            char user_db_filename[BUF_SIZE];
            snprintf(user_db_filename, sizeof(user_db_filename), "database/%s.txt", username);
            printf("%s\n",user_db_filename);
            int fd = open(user_db_filename, O_RDONLY);
            printf("%d\n",fd);
            if (fd >= 0) {
                struct stat file_stat;
                if (fstat(fd, &file_stat) == 0 && file_stat.st_size == 0) {
                    send(new_socket, "File is empty\n", 14, 0);
                }
                else{
                while ((n = read(fd, buffer, BUF_SIZE)) > 0) {
                    printf("buuuuuuufffufufu :%s\n",buffer);
                    write(new_socket, buffer, n);
                }
                }
                close(fd);
            } else {
                send(new_socket, "Failed to open user database\n", 28, 0);
            }
            printf("done done done \n");
            pthread_mutex_unlock(&file_lock);
        }
        
        else {
            send(new_socket, "Invalid command or insufficient privileges\n", 43, 0);
        }
    }

    // Notify server that the client connection has been closed
    printf("Client disconnected from socket %d\n", new_socket);
    close(new_socket);
    return NULL;
}

int main() {
    int server_fd, new_socket, *client_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    pthread_t tid;

    // Initialize mutex
    pthread_mutex_init(&file_lock, NULL);

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Bind socket
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d\n", PORT);

    while ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) >= 0) {
        client_socket = malloc(sizeof(int));
        *client_socket = new_socket;
        pthread_create(&tid, NULL, handle_client, (void*)client_socket);
    }

    if (new_socket < 0) {
        perror("Accept failed");
        exit(EXIT_FAILURE);
    }

    // Destroy mutex
    pthread_mutex_destroy(&file_lock);

    return 0;
}