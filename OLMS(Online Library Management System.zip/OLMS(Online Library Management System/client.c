#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUF_SIZE 1024

void sign_up(int sock) {
    char buffer[BUF_SIZE];
    char user_type[BUF_SIZE], username[BUF_SIZE], password[BUF_SIZE];

    // printf("Enter user type (user): ");
    // fgets(user_type, BUF_SIZE, stdin);
    // user_type[strcspn(user_type, "\n")] = 0;
    send(sock,"SIGN_UP",strlen("SIGN_UP"),0);
    sleep(0.5);
    send(sock,"user",strlen("user"),0);
    
    printf("Enter username: ");
    fgets(username, BUF_SIZE, stdin);
    username[strcspn(username, "\n")] = 0;
    send(sock,username,strlen(username),0);
    
    printf("Enter password: ");
    fgets(password, BUF_SIZE, stdin);
    password[strcspn(password, "\n")] = 0;
    send(sock,password,strlen(password),0);
    // snprintf(buffer, BUF_SIZE, "SIGN_UP %s %s %s", "user", username, password);
    // send(sock, buffer, strlen(buffer), 0);

    // Receive sign-up response
    int n = read(sock, buffer, BUF_SIZE);
    buffer[n] = '\0';
    printf("%s", buffer);
}


int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[BUF_SIZE] = {0};
    char user_type[BUF_SIZE] = {0};
    char username[BUF_SIZE] = {0};
    char password[BUF_SIZE] = {0};
    char choice[BUF_SIZE];

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("\nConnection Failed \n");
        return -1;
    }

    // Notify client that the connection is established
    int n = read(sock, buffer, BUF_SIZE);
    buffer[n] = '\0';
    printf("%s", buffer);


    printf("Do you want to Sign Up or Log In? (Enter 'SIGN_UP' or 'LOG_IN'): ");
    fgets(choice, BUF_SIZE, stdin);
    choice[strcspn(choice, "\n")] = 0;

    if (strcmp(choice, "SIGN_UP") == 0) {
        sign_up(sock);
        strcpy(choice,"LOG_IN");
    }
    else
    {
    send(sock,"LOG_IN",strlen("LOG_IN"),0);
    }

    //sleep(0.5);
    // Ask the user for user type
    printf("Are you an admin or a normal user? (Enter 'admin' or 'user'): ");
    fgets(user_type, BUF_SIZE, stdin);
    user_type[strcspn(user_type, "\n")] = 0;

    // Send user type to the server
    send(sock, user_type, strlen(user_type), 0);

    // Send username and password
    printf("Enter username: ");
    fgets(username, BUF_SIZE, stdin);
    username[strcspn(username, "\n")] = 0;
    send(sock, username, strlen(username), 0);

    printf("Enter password: ");
    fgets(password, BUF_SIZE, stdin);
    password[strcspn(password, "\n")] = 0;
    send(sock, password, strlen(password), 0);

    // Receive authentication response
    n = read(sock, buffer, BUF_SIZE);
    buffer[n] = '\0';
    printf("%s", buffer);

    if (strcmp(buffer, "Authentication failed\n") == 0) {
        close(sock);
        return -1;
    }

    while (1) {
        
        if(strcmp(user_type,"admin") == 0)
        {    
        printf("Enter command (ADD_BOOK/DELETE_BOOK/MODIFY_BOOK/ADD_USER/DELETE_USER/ADD_ADMIN/DELETE_ADMIN/VIEW_LIBRARY/EXIT): ");
        fgets(buffer, BUF_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = 0;
        
        // Send the command to the server
        send(sock, buffer, strlen(buffer), 0);

        if (strcmp(buffer, "EXIT") == 0) {
            break;
        }

        if (strcmp(buffer, "ADD_BOOK") == 0 && strcmp(user_type, "admin") == 0) {
            char book_info[BUF_SIZE];
            printf("Enter book info (name, author, quantity): ");
            fgets(book_info, BUF_SIZE, stdin);
            book_info[strcspn(book_info, "\n")] = 0;
            send(sock, book_info, strlen(book_info), 0);
        }

        if (strcmp(buffer, "DELETE_BOOK") == 0 && strcmp(user_type, "admin") == 0) {
            char book_name[BUF_SIZE];
            printf("Enter the name of the book to delete: ");
            fgets(book_name, BUF_SIZE, stdin);
            book_name[strcspn(book_name, "\n")] = 0;
            send(sock, book_name, strlen(book_name), 0);
        }

        if(strcmp(buffer, "MODIFY_BOOK") == 0 && strcmp(user_type, "admin") == 0){
            char book_name[BUF_SIZE];
            char quantity[BUF_SIZE];
            printf("Enter the name of the book whose quantity need to be modified: ");
            fgets(book_name, BUF_SIZE, stdin);
            book_name[strcspn(book_name, "\n")] = 0;
            send(sock, book_name, strlen(book_name), 0);
            printf("New quantity: ");
            fgets(quantity, BUF_SIZE, stdin);
            quantity[strcspn(quantity, "\n")] = 0;
            send(sock, quantity, strlen(quantity), 0);
            
        }

        if (strcmp(buffer, "ADD_USER") == 0 && strcmp(user_type, "admin") == 0) {
            char new_username[BUF_SIZE], new_password[BUF_SIZE];
            printf("Enter new username: ");
            fgets(new_username, BUF_SIZE, stdin);
            new_username[strcspn(new_username, "\n")] = 0;
            send(sock, new_username, strlen(new_username), 0);
            printf("Enter new password): ");
            fgets(new_password, BUF_SIZE, stdin);
            new_password[strcspn(new_password, "\n")] = 0;
            send(sock, new_password, strlen(new_password), 0);
        }

        if (strcmp(buffer, "DELETE_USER") == 0 && strcmp(user_type, "admin") == 0) {
            char del_username[BUF_SIZE];
            printf("Enter the username of the user to delete: ");
            fgets(del_username, BUF_SIZE, stdin);
            del_username[strcspn(del_username, "\n")] = 0;
            send(sock, del_username, strlen(del_username), 0);
        }

        if (strcmp(buffer, "ADD_ADMIN") == 0 && strcmp(user_type, "admin") == 0) {
            char new_username[BUF_SIZE], new_password[BUF_SIZE];
            printf("Enter admin info (username, password): ");
            fgets(new_username, BUF_SIZE, stdin);
            new_username[strcspn(new_username, "\n")] = 0;
            send(sock, new_username, strlen(new_username), 0);
            fgets(new_password, BUF_SIZE, stdin);
            new_password[strcspn(new_password, "\n")] = 0;
            send(sock, new_password, strlen(new_password), 0);
        }

        if(strcmp(buffer,"DELETE_ADMIN") == 0 && strcmp(user_type,"admin") == 0)
        {   
            char del_username[BUF_SIZE];
            printf("Enter the username of the admin to delete: ");
            fgets(del_username, BUF_SIZE, stdin);
            del_username[strcspn(del_username, "\n")] = 0;
            send(sock, del_username, strlen(del_username), 0);

        }

        // if(strcmp(buffer,"VIEW_LIBRARY") == 0 && strcmp(user_type, "admin") == 0)
        // {

        // }

        }
        else if(strcmp(user_type,"user") == 0)
        {
        printf("Enter command (BORROW_BOOK/RETURN_BOOK/VIEW_BOOK/VIEW_LIBRARY/EXIT): ");
        fgets(buffer, BUF_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = 0;
        
        // Send the command to the server
        send(sock, buffer, strlen(buffer), 0);

        if (strcmp(buffer, "EXIT") == 0) {
            break;
        }

        if(strcmp(buffer,"BORROW_BOOK") == 0)
        {
            char username[BUF_SIZE], book_name[BUF_SIZE];
            //printf("Enter your username: ");
            //fgets(username, BUF_SIZE, stdin);
            //username[strcspn(username,"\n")] = 0;
            //send(sock,username,strlen(username),0);
            //char username[BUF_SIZE], book_name[BUF_SIZE];
            printf("Enter your book name: ");
            fgets(book_name, BUF_SIZE, stdin);
            book_name[strcspn(book_name,"\n")] = 0;
            send(sock,book_name,strlen(book_name),0);
        }

        if(strcmp(buffer,"RETURN_BOOK") == 0)
        {
            char username[BUF_SIZE], book_name[BUF_SIZE];
            // printf("Enter your username: ");
            // fgets(username, BUF_SIZE, stdin);
            // username[strcspn(username, "\n")] = 0;
            // send(sock, username, strlen(username), 0);

            printf("Enter book name: ");
            fgets(book_name, BUF_SIZE, stdin);
            book_name[strcspn(book_name, "\n")] = 0;
            send(sock, book_name, strlen(book_name), 0);
        }
        // if(strcmp(buffer,"SIGN_UP") == 0)
        // {
        //     char buffer[BUF_SIZE];
        //     char user_type[BUF_SIZE], username[BUF_SIZE], password[BUF_SIZE];

        //     printf("Enter user type (user): ");
        //     fgets(user_type, BUF_SIZE, stdin);
        //     user_type[strcspn(user_type, "\n")] = 0;

        //     printf("Enter username: ");
        //     fgets(username, BUF_SIZE, stdin);
        //     username[strcspn(username, "\n")] = 0;

        //     printf("Enter password: ");
        //     fgets(password, BUF_SIZE, stdin);
        //     password[strcspn(password, "\n")] = 0;

        //     snprintf(buffer, BUF_SIZE, "%s %s %s", user_type, username, password);
        //     send(sock, buffer, strlen(buffer), 0);

        // }

        // if(strcmp(buffer,"VIEW_BOOK") == 0)
        // {
        //     send(sock,username,strlen(username),0);
        // }

        }

        // Receive and print server response
        n = read(sock, buffer, BUF_SIZE);
        //printf("%d \n",n);
        buffer[n] = '\0';
        printf("%s\n", buffer);
    }

    close(sock);
    return 0;
}
